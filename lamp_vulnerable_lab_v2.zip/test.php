<?php
$results = [];
$show_results = false;
$score = 0;
$total = 5;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $show_results = true;

    $answers = [
        'php_version' => 'PHP/7.4.3',
        'server_software' => 'nginx/1.18.0',
        'sql_error' => 'You have an error in your SQL syntax',
        'lfi_payload' => '../index2.php',
        'cmd_payload' => 'id'
    ];

    $user_answers = [
        'php_version' => trim($_POST['php_version'] ?? ''),
        'server_software' => trim($_POST['server_software'] ?? ''),
        'sql_error' => trim($_POST['sql_error'] ?? ''),
        'lfi_payload' => trim($_POST['lfi_payload'] ?? ''),
        'cmd_payload' => trim($_POST['cmd_payload'] ?? '')
    ];

    // Sprawdzenia
    $results['php_version'] = ($user_answers['php_version'] === $answers['php_version']);
    $results['server_software'] = (strpos($user_answers['server_software'], $answers['server_software']) !== false);
    $results['sql_error'] = (strpos($user_answers['sql_error'], $answers['sql_error']) !== false);
    $results['lfi_payload'] = ($user_answers['lfi_payload'] === $answers['lfi_payload']);
    $results['cmd_payload'] = (strpos($user_answers['cmd_payload'], $answers['cmd_payload']) !== false);

    foreach ($results as $result) {
        if ($result) {
            $score++;
        }
    }
}

function get_result_class($key, $results, $show_results) {
    if (!$show_results) return '';
    return $results[$key] ? 'correct' : 'incorrect';
}

?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Wiedzy - Laboratorium Audytowe</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #1a1a1a; color: #e0e0e0; margin: 0; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: #2d2d2d; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
        h1 { color: #4af3ff; border-bottom: 2px solid #4af3ff; padding-bottom: 10px; margin-top: 0; }
        a { color: #4af3ff; }
        .question-group { margin-bottom: 20px; background: #333; padding: 20px; border-radius: 6px; border-left: 4px solid #555; }
        label { display: block; margin-bottom: 8px; font-weight: bold; color: #e0e0e0; }
        input[type="text"] { width: 100%; padding: 10px; background: #222; border: 1px solid #555; color: #fff; border-radius: 4px; box-sizing: border-box; }
        input[type="submit"] { background: #4af3ff; color: #1a1a1a; border: none; padding: 12px 25px; cursor: pointer; border-radius: 4px; font-weight: bold; font-size: 1.1em; margin-top: 20px; }
        input[type="submit"]:hover { background: #38e0f0; }
        .score { background: #111; border: 1px solid #4af3ff; padding: 15px; margin-bottom: 20px; text-align: center; font-size: 1.2em; }
        .correct { border-left-color: #4aff4a; }
        .incorrect { border-left-color: #ff4a4a; }
        .feedback { font-size: 0.9em; margin-top: 8px; }
        .feedback.correct { color: #4aff4a; }
        .feedback.incorrect { color: #ff4a4a; }
        code { background: #111; padding: 2px 5px; border-radius: 3px; color: #ffb64a; }
    </style>
</head>
<body>

<div class="container">
    <h1>Sprawdź swoją wiedzę!</h1>
    <p>Po przeprowadzeniu rekonesansu na stronie <a href="index2.php" target="_blank">index2.php</a>, spróbuj odpowiedzieć na poniższe pytania, aby sprawdzić, co udało Ci się odkryć.</p>

    <?php if ($show_results): ?>
        <div class="score">Twój wynik: <?php echo $score; ?> / <?php echo $total; ?></div>
    <?php endif; ?>

    <form method="POST" action="test.php">
        <div class="question-group <?php echo get_result_class('php_version', $results, $show_results); ?>">
            <label for="php_version">1. Jaka wersja PHP jest ujawniona w nagłówkach strony <code>index2.php</code>?</label>
            <input type="text" id="php_version" name="php_version" value="<?php echo htmlspecialchars($_POST['php_version'] ?? ''); ?>">
            <?php if ($show_results && !$results['php_version']): ?>
                <div class="feedback incorrect">Niepoprawna odpowiedź. Sprawdź nagłówek `X-Powered-By` w narzędziach deweloperskich przeglądarki.</div>
            <?php elseif ($show_results && $results['php_version']): ?>
                <div class="feedback correct">Poprawna odpowiedź!</div>
            <?php endif; ?>
        </div>

        <div class="question-group <?php echo get_result_class('server_software', $results, $show_results); ?>">
            <label for="server_software">2. Jakie oprogramowanie serwera (i wersja) jest ujawnione w nagłówkach?</label>
            <input type="text" id="server_software" name="server_software" value="<?php echo htmlspecialchars($_POST['server_software'] ?? ''); ?>">
            <?php if ($show_results && !$results['server_software']): ?>
                <div class="feedback incorrect">Niepoprawna odpowiedź. Sprawdź nagłówek `Server`.</div>
            <?php elseif ($show_results && $results['server_software']): ?>
                <div class="feedback correct">Poprawna odpowiedź!</div>
            <?php endif; ?>
        </div>

        <div class="question-group <?php echo get_result_class('sql_error', $results, $show_results); ?>">
            <label for="sql_error">3. Jaki komunikat błędu SQL pojawia się w wyszukiwarce artykułów po wpisaniu samego apostrofu (<code>'</code>)? (Wklej kluczowy fragment błędu)</label>
            <input type="text" id="sql_error" name="sql_error" value="<?php echo htmlspecialchars($_POST['sql_error'] ?? ''); ?>">
            <?php if ($show_results && !$results['sql_error']): ?>
                <div class="feedback incorrect">Niepoprawna odpowiedź. Poszukaj błędu związanego ze składnią SQL.</div>
            <?php elseif ($show_results && $results['sql_error']): ?>
                <div class="feedback correct">Poprawna odpowiedź!</div>
            <?php endif; ?>
        </div>

        <div class="question-group <?php echo get_result_class('lfi_payload', $results, $show_results); ?>">
            <label for="lfi_payload">4. Jaki payload (sama ścieżka pliku) należy podać w parametrze <code>download_file</code>, aby odczytać zawartość pliku <code>index2.php</code>?</label>
            <input type="text" id="lfi_payload" name="lfi_payload" value="<?php echo htmlspecialchars($_POST['lfi_payload'] ?? ''); ?>">
            <?php if ($show_results && !$results['lfi_payload']): ?>
                <div class="feedback incorrect">Niepoprawna odpowiedź. Pamiętaj, że skrypt znajduje się w katalogu `documents`.</div>
            <?php elseif ($show_results && $results['lfi_payload']): ?>
                <div class="feedback correct">Poprawna odpowiedź!</div>
            <?php endif; ?>
        </div>
        
        <div class="question-group <?php echo get_result_class('cmd_payload', $results, $show_results); ?>">
            <label for="cmd_payload">5. Jakiego polecenia systemowego (samego polecenia) użyjesz, aby sprawdzić, kim jest aktualny użytkownik systemu za pomocą podatności w narzędziach sieciowych?</label>
            <input type="text" id="cmd_payload" name="cmd_payload" placeholder="np. whoami, id, ..." value="<?php echo htmlspecialchars($_POST['cmd_payload'] ?? ''); ?>">
            <?php if ($show_results && !$results['cmd_payload']): ?>
                <div class="feedback incorrect">Niepoprawna odpowiedź. Popularne polecenie w systemach Linux to `id`.</div>
            <?php elseif ($show_results && $results['cmd_payload']): ?>
                <div class="feedback correct">Poprawna odpowiedź!</div>
            <?php endif; ?>
        </div>

        <input type="submit" value="Sprawdź odpowiedzi">
    </form>
</div>

</body>
</html>