#!/bin/bash

# Skrypt automatycznej instalacji i konfiguracji srodowiska LAMP na Debian 13
set -e

echo "[+] Aktualizacja pakietow..."
sudo apt update

echo "[+] Instalacja Apache2, MariaDB (MySQL) oraz PHP..."
sudo apt install -y apache2 mariadb-server php libapache2-mod-php php-mysql

echo "[+] Konfiguracja i uruchamianie uslug..."
sudo systemctl enable apache2
sudo systemctl start apache2
sudo systemctl enable mariadb
sudo systemctl start mariadb

echo "[+] Tworzenie bazy danych oraz uzytkownika laboratoryjnego..."
# Tworzymy baze, uzytkownika i nadajemy uprawnienia
sudo mysql -e "CREATE DATABASE IF NOT EXISTS lab_db;"
sudo mysql -e "CREATE USER IF NOT EXISTS 'lab_user'@'localhost' IDENTIFIED BY 'SilneHasloBazy123!';"
sudo mysql -e "GRANT ALL PRIVILEGES ON lab_db.* TO 'lab_user'@'localhost';"
sudo mysql -e "FLUSH PRIVILEGES;"

echo "[+] Importowanie podatnej struktury bazy danych..."
if [ -f "./database.sql" ]; then
    sudo mysql lab_db < ./database.sql
    echo "[+] Baza danych zaimportowana pomyślnie."
else
    echo "[!] Brak pliku database.sql w biezacym katalogu!"
fi

echo "[+] Wdrażanie podatnej aplikacji webowej (pliki .php)..."
# Kopiowanie wszystkich plików PHP
sudo rm -f /var/www/html/index.html
if ls ./*.php 1> /dev/null 2>&1; then
    sudo cp ./*.php /var/www/html/
    # Ustawienie odpowiednich uprawnien dla serwera www
    sudo chown -R www-data:www-data /var/www/html/
    sudo chmod -R 755 /var/www/html/
    echo "[+] Pliki wdrożone pomyślnie w /var/www/html/"
else
    echo "[!] Brak plików .php w bieżącym katalogu!"
fi

echo "[+] Restartowanie serwera Apache..."
sudo systemctl restart apache2

echo -e "\n[+] SKRYPT ZAKONCZYL PRACE SUKCESEM!"
echo "--------------------------------------------------------"
echo "Twoje lokalne laboratorium jest gotowe."
echo "Wejdz w przegladarce na adresy:"
echo "-> http://localhost/index.php"
echo "-> http://localhost/index2.php"
echo "-> http://localhost/test.php"
echo "--------------------------------------------------------"
