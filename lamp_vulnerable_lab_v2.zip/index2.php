<?php
// --- Konfiguracja i połączenie z bazą danych ---
ini_set('display_errors', 1); // Błędy są pokazywane, aby umożliwić Error-Based SQLi
error_reporting(E_ALL);

// --- Podatne nagłówki (inne niż w index.php) ---
header('X-Powered-By: PHP/7.4.3'); // Inna, nowsza wersja PHP
header('Server: nginx/1.18.0');   // Inny serwer (nginx)

$conn = new mysqli("localhost", "lab_user", "SilneHasloBazy123!", "lab_db");
if ($conn->connect_error) {
    // Cichy błąd, nic nie wyświetlamy
    die("Connection failed: " . $conn->connect_error);
}

// --- Obsługa podatności ---

// 1. SQL Injection (wyszukiwarka artykułów)
$articles = [];
$sql_error = null;
if (isset($_GET['search'])) {
    $search_term = $_GET['search'];
    // PODATNOŚĆ: Error-based SQLi. Dane są wstawiane bezpośrednio do zapytania.
    $query = "SELECT title, content FROM articles WHERE title LIKE '%$search_term%'";
    $result = $conn->query($query);
    if ($result) {
        $articles = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $sql_error = $conn->error;
    }
}

// 2. Reflected XSS (formularz kontaktowy)
$feedback_message = '';
if (isset($_POST['message'])) {
    // PODATNOŚĆ: Reflected XSS. Wiadomość jest wyświetlana bez użycia htmlspecialchars().
    $feedback_message = "Dziękujemy za Twoją wiadomość: " . $_POST['message'];
}

// 3. Command Injection (narzędzia sieciowe)
$ping_output = null;
if (isset($_POST['domain'])) {
    $domain = $_POST['domain'];
    // PODATNOŚĆ: Command Injection. Brak sanitacji danych wejściowych.
    $cmd = "ping -c 4 " . $domain;
    $ping_output = shell_exec($cmd);
}

// 4. LFI (pobieranie plików)
if (isset($_GET['download_file'])) {
    $file = $_GET['download_file'];
    $file_path = 'documents/' . $file; // PODATNOŚĆ: LFI / Path Traversal
    
    if (file_exists($file_path) && is_readable($file_path)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file_path));
        readfile($file_path);
        exit;
    }
}

// 5. IDOR (przeglądanie profili pracowników)
$employee_data = null;
if (isset($_GET['employee_id'])) {
    // Zapytanie jest bezpieczne (odporne na SQLi), ale logika ma lukę (brak sprawdzania uprawnień).
    $stmt = $conn->prepare("SELECT id, username, role, secret_note FROM users WHERE id = ?");
    $stmt->bind_param("i", $_GET['employee_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        $employee_data = $result->fetch_assoc();
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Strona Firmowa - TechCorp</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f9; color: #333; margin: 0; padding: 0; }
        .navbar { background: #fff; padding: 1rem; border-bottom: 1px solid #ddd; text-align: center; }
        .navbar a { text-decoration: none; color: #333; margin: 0 15px; font-weight: bold; }
        .container { max-width: 1100px; margin: 2rem auto; padding: 1rem; }
        .section { background: #fff; padding: 2rem; margin-bottom: 2rem; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        h1, h2 { color: #0056b3; }
        label { display: block; margin-bottom: 5px; }
        input[type="text"], textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; margin-bottom: 10px; }
        input[type="submit"] { background: #0056b3; color: #fff; border: none; padding: 10px 20px; cursor: pointer; border-radius: 4px; }
        input[type="submit"]:hover { background: #004494; }
        pre { background: #2d2d2d; color: #f1f1f1; padding: 15px; border-radius: 5px; overflow-x: auto; }
        .article { border-bottom: 1px solid #eee; padding-bottom: 1rem; margin-bottom: 1rem; }
        .article:last-child { border-bottom: none; }
    </style>
</head>
<body>

<nav class="navbar">
    <a href="#news">Aktualności</a>
    <a href="#contact">Kontakt</a>
    <a href="#tools">Narzędzia</a>
    <a href="#employees">Pracownicy</a>
</nav>

<div class="container">
    <h1>Witaj na stronie TechCorp!</h1>

    <!-- SEKCJA 1: SQLi -->
    <div id="news" class="section">
        <h2>Aktualności i artykuły</h2>
        <form method="GET" action="#news">
            <label for="search">Wyszukaj artykuł:</label>
            <input type="text" id="search" name="search" placeholder="np. ' OR 1=1 -- ">
            <input type="submit" value="Szukaj">
        </form>
        <?php if ($sql_error): ?>
            <p>Wystąpił błąd podczas wyszukiwania.</p>
            <pre><?php echo htmlspecialchars($sql_error); ?></pre>
        <?php endif; ?>
        <?php if (!empty($articles)): ?>
            <h3>Wyniki wyszukiwania:</h3>
            <?php foreach($articles as $article): ?>
                <div class="article">
                    <h4><?php echo htmlspecialchars($article['title']); ?></h4>
                    <p><?php echo htmlspecialchars($article['content']); ?></p>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        <hr>
        <h4>Do pobrania</h4>
        <p>Pobierz nasz oficjalny regulamin: <a href="?download_file=regulamin.txt">regulamin.txt</a></p>
        <p style="font-size:0.9em; color:#777;"><i>(Podpowiedź LFI: spróbuj pobrać inny plik, np. `?download_file=../index2.php`)</i></p>
    </div>

    <!-- SEKCJA 2: XSS -->
    <div id="contact" class="section">
        <h2>Formularz kontaktowy</h2>
        <form method="POST" action="#contact">
            <label for="message">Twoja wiadomość:</label>
            <textarea id="message" name="message" rows="4" placeholder="<script>alert('XSS')</script>"></textarea>
            <input type="submit" value="Wyślij">
        </form>
        <?php if ($feedback_message): ?>
            <div style="margin-top: 20px; padding: 15px; background: #e9f7ef; border-left: 4px solid #28a745; color: #155724;">
                <?php echo $feedback_message; // PODATNOŚĆ ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- SEKCJA 3: Command Injection -->
    <div id="tools" class="section">
        <h2>Narzędzia sieciowe</h2>
        <p>Sprawdź dostępność domeny za pomocą polecenia ping.</p>
        <form method="POST" action="#tools">
            <label for="domain">Domena lub adres IP:</label>
            <input type="text" id="domain" name="domain" placeholder="8.8.8.8; ls -l">
            <input type="submit" value="Testuj">
        </form>
        <?php if ($ping_output !== null): ?>
            <h4>Wynik polecenia:</h4>
            <pre><?php echo htmlspecialchars($ping_output); ?></pre>
        <?php endif; ?>
    </div>

    <!-- SEKCJA 4: IDOR -->
    <div id="employees" class="section">
        <h2>Nasi pracownicy</h2>
        <p>Zobacz profile naszych kluczowych pracowników.</p>
        <ul>
            <li><a href="?employee_id=1#employees">Profil Jana Kowalskiego (ID: 1)</a></li>
            <li><a href="?employee_id=2#employees">Profil Anny Nowak (ID: 2)</a></li>
        </ul>
        <?php if ($employee_data): ?>
            <h4 style="margin-top:20px;">Profil pracownika: <?php echo htmlspecialchars($employee_data['username']); ?></h4>
            <ul>
                <li><strong>ID:</strong> <?php echo htmlspecialchars($employee_data['id']); ?></li>
                <li><strong>Rola:</strong> <?php echo htmlspecialchars($employee_data['role']); ?></li>
                <li><strong>Poufna notatka:</strong> <span style="color: #c00;"><?php echo htmlspecialchars($employee_data['secret_note']); ?></span></li>
            </ul>
        <?php elseif (isset($_GET['employee_id'])): ?>
            <p style="margin-top:20px;">Pracownik o podanym ID nie został znaleziony.</p>
        <?php endif; ?>
    </div>

</div>

</body>
</html>