<?php
// Wylaczenie wyswietlania domyslnych bledow, ale pokazanie ich w celach edukacyjnych
ini_set('display_errors', 1);
error_reporting(E_ALL);

// PODATNOSC: Ujawnienie wersji oprogramowania i niestandardowe, potencjalnie wrażliwe nagłówki
// Te nagłówki mogą być wykryte przez skanery takie jak Nuclei
header('X-Powered-By: PHP/5.4.0'); // Ujawnienie starej wersji PHP
header('Server: Apache/2.2.15 (CentOS)'); // Ujawnienie wersji serwera
header('X-Custom-Vulnerable-Header: backup-config.php.bak'); // Niestandardowy nagłówek wskazujący na potencjalnie wrażliwy plik

// Polaczenie z baza danych
$conn = new mysqli("localhost", "lab_user", "SilneHasloBazy123!", "lab_db");

if ($conn->connect_error) {
    $db_status = "Brak polaczenia z baza: " . $conn->connect_error;
} else {
    $db_status = "Polaczono pomyślnie z baza: lab_db";
}

// Obsluga podatnosci SQL Injection (SQLi)
$user_data = null;
$sqli_err = null;
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // PODATNOSC: Bezposrednie wstrzykniecie zmiennej do zapytania SQL zamiast Prepared Statements
    $query = "SELECT id, username, role, secret_note FROM users WHERE id = " . $id;
    
    $result = $conn->query($query);
    if ($result) {
        $user_data = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $sqli_err = $conn->error;
    }
}

// Obsluga podatnosci Cross-Site Scripting (XSS)
$xss_output = "";
if (isset($_POST['comment'])) {
    // PODATNOSC: Brak uzycia htmlspecialchars() lub filtrowania - dane leca prosto do przegladarki
    $xss_output = $_POST['comment'];
}

// Obsługa podatności Command Injection
$cmd_output = null;
if (isset($_POST['ip'])) {
    $ip = $_POST['ip'];
    // PODATNOSC: Bezpośrednie wykonanie polecenia z danymi od użytkownika
    // Atakujący może dodać do adresu IP inne polecenia, np. "8.8.8.8; ls -la"
    $cmd = "ping -c 3 " . $ip;
    $cmd_output = shell_exec($cmd);
}

// Obsługa podatności Local File Inclusion (LFI)
$lfi_page_content = null;
$lfi_page = isset($_GET['page']) ? $_GET['page'] : null;
if ($lfi_page) {
    // PODATNOSC: Dołączanie pliku na podstawie parametru GET bez walidacji
    // Atakujący może próbować dołączyć pliki systemowe, np. ?page=../../../../etc/passwd
    // ob_start() i ob_get_clean() są użyte do przechwycenia wyniku include, aby nie zepsuć reszty strony
    ob_start();
    // Użycie @, aby stłumić błędy, jeśli plik nie zostanie znaleziony.
    @include($lfi_page);
    $lfi_page_content = ob_get_clean();
}

// Obsługa podatności Insecure Direct Object Reference (IDOR)
$idor_user_data = null;
if (isset($_GET['idor_user_id'])) {
    // Używamy prepared statement, aby ta sekcja NIE była podatna na SQLi,
    // co pozwala skupić się wyłącznie na podatności IDOR.
    $stmt = $conn->prepare("SELECT id, username, role, secret_note FROM users WHERE id = ?");
    $stmt->bind_param("i", $_GET['idor_user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        $idor_user_data = $result->fetch_assoc();
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lokalne Srodowisko Audytowe - Testy Podatnosci</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #1a1a1a; color: #e0e0e0; margin: 0; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: #2d2d2d; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); }
        h1 { color: #ff4a4a; border-bottom: 2px solid #ff4a4a; padding-bottom: 10px; margin-top: 0; }
        h2 { color: #4af3ff; margin-top: 30px; }
        a { color: #4af3ff; }
        a:hover { color: #8affff; }
        ul li a {
            word-break: break-all;
        }
        .status { padding: 10px; background: #3a3a3a; border-left: 4px solid #4aff4a; margin-bottom: 20px; border-radius: 4px; }
        .status.error { border-left-color: #ff4a4a; }
        .box { background: #333; padding: 20px; border-radius: 6px; margin-bottom: 20px; border: 1px solid #444; }
        input[type="text"], textarea { width: 100%; padding: 10px; background: #222; border: 1px solid #555; color: #fff; border-radius: 4px; box-sizing: border-box; margin-bottom: 10px; }
        input[type="submit"] { background: #ff4a4a; color: #fff; border: none; padding: 10px 20px; cursor: pointer; border-radius: 4px; font-weight: bold; }
        input[type="submit"]:hover { background: #e03838; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #555; }
        th { background: #444; color: #4af3ff; }
        pre { background: #111; padding: 15px; color: #ff4a4a; overflow-x: auto; border-radius: 4px; }
        .hint { font-size: 0.9em; color: #aaa; font-style: italic; margin-top: 5px; }

        @media (max-width: 768px) {
            body { padding: 5px; }
            .container {
                padding: 15px;
                width: auto;
            }
            h1 { font-size: 1.5em; }
            h2 { font-size: 1.2em; }
            th, td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <h1>Laboratorium Audytowe (LAMP)</h1>
    <div class="status <?php echo $conn->connect_error ? 'error' : ''; ?>">
        <strong>Status Systemu:</strong> <?php echo $db_status; ?>
    </div>

    <!-- SEKCJA SQL INJECTION -->
    <h2>1. Podatność: SQL Injection (Union Based / Error Based)</h2>
    <div class="box">
        <p>Aplikacja pobiera dane profilu na podstawie parametru GET <code>id</code>.</p>
        <form method="GET" action="">
            <label for="id">Podaj ID użytkownika (np. 1, 2):</label>
            <input type="text" id="id" name="id" value="<?php echo isset($_GET['id']) ? htmlspecialchars($_GET['id']) : '1'; ?>">
            <input type="submit" value="Pobierz dane profilu">
        </form>
        
        <?php if (isset($query)): ?>
            <p class="hint">Wykonywane zapytanie SQL w kodzie źródłowym:</p>
            <code style="color: #ffb64a; display:block; background:#222; padding:8px; border-radius:4px;"><?php echo htmlspecialchars($query); ?></code>
        <?php endif; ?>

        <?php if ($sqli_err): ?>
            <h3>Błąd bazy danych (Error-Based SQLi Helper):</h3>
            <pre><?php echo htmlspecialchars($sqli_err); ?></pre>
        <?php endif; ?>

        <?php if ($user_data): ?>
            <h3>Wynik zapytania:</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nazwa użytkownika</th>
                        <th>Rola w systemie</th>
                        <th>Tajne Notatki (Cel ataku)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($user_data as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['role']); ?></td>
                            <td><?php echo htmlspecialchars($user['secret_note']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <!-- SEKCJA CROSS-SITE SCRIPTING -->
    <h2>2. Podatność: Reflected / Stored Cross-Site Scripting (XSS)</h2>
    <div class="box">
        <p>Dodaj komentarz na stronę. Kod nie jest filtrowany przed wyświetleniem.</p>
        <form method="POST" action="">
            <label for="comment">Wpisz treść komentarza:</label>
            <textarea id="comment" name="comment" rows="3" placeholder="<script>alert('XSS')</script>"></textarea>
            <input type="submit" value="Wyślij komentarz">
        </form>

        <?php if ($xss_output !== ""): ?>
            <div style="margin-top: 20px; padding: 15px; background: #444; border-radius: 4px;">
                <h4>Ostatnio dodany komentarz (Wyrenderowany bezpośrednio w HTML):</h4>
                <div class="comment-render">
                    <?php echo $xss_output; ?>
                </div>
            </div>
        <?php endif; ?>
    </div> <!-- Koniec sekcji XSS -->
    
    <!-- SEKCJA COMMAND INJECTION -->
    <h2>3. Podatność: Command Injection (RCE)</h2>
    <div class="box">
        <p>Aplikacja pozwala na wykonanie polecenia <code>ping</code> na podany adres IP. Brak odpowiedniej walidacji i sanitacji danych wejściowych prowadzi do możliwości wykonania dowolnego polecenia w systemie (Remote Code Execution).</p>
        <form method="POST" action="">
            <label for="ip">Podaj adres IP do pingowania (np. 8.8.8.8):</label>
            <input type="text" id="ip" name="ip" placeholder="8.8.8.8; whoami">
            <input type="submit" value="Pinguj">
        </form>

        <?php if ($cmd_output !== null): ?>
            <h4 style="margin-top:20px;">Wynik polecenia:</h4>
            <pre><?php echo htmlspecialchars($cmd_output); ?></pre>
        <?php endif; ?>
    </div>

    <!-- SEKCJA LOCAL FILE INCLUSION -->
    <h2>4. Podatność: Local File Inclusion (LFI)</h2>
    <div class="box">
        <p>Aplikacja dynamicznie dołącza treść strony na podstawie parametru <code>page</code>. Brak walidacji ścieżki pozwala na dołączenie dowolnych plików z serwera.</p>
        <p>Przykłady do przetestowania (aby zachować kontekst strony, do linków dodano <code>id=1</code>):</p>
        <ul>
            <li><a href="?page=index.php&id=1">?page=index.php</a> (dołączenie samego siebie)</li>
            <li><a href="?page=/etc/passwd&id=1">?page=/etc/passwd</a> (próba odczytu pliku systemowego)</li>
        </ul>
        
        <?php if ($lfi_page): ?>
            <div style="margin-top: 20px; padding: 15px; background: #111; border: 1px solid #444; border-radius: 4px;">
                <h4>Zawartość dołączonego pliku (<code><?php echo htmlspecialchars($lfi_page); ?></code>):</h4>
                <pre><?php echo htmlspecialchars($lfi_page_content); ?></pre>
            </div>
        <?php endif; ?>
    </div>

    <!-- SEKCJA INSECURE DIRECT OBJECT REFERENCE (IDOR) -->
    <h2>5. Podatność: Insecure Direct Object Reference (IDOR)</h2>
    <div class="box">
        <p>Aplikacja pozwala na przeglądanie "prywatnego profilu" użytkownika na podstawie jego ID. Zapytanie do bazy danych jest bezpieczne (odporne na SQLi), ale aplikacja nie weryfikuje, czy zalogowany użytkownik ma uprawnienia do przeglądania profilu o podanym ID.</p>
        <p class="hint">W realnej aplikacji brakowałoby tu sprawdzenia, czy ID zalogowanego użytkownika jest takie samo jak ID, do którego próbuje uzyskać dostęp (np. <code>if ($_SESSION['user_id'] == $_GET['idor_user_id'])</code>).</p>
        <form method="GET" action="">
            <label for="idor_user_id">Podaj ID użytkownika, którego profil chcesz zobaczyć (np. 1, 2, 3):</label>
            <input type="text" id="idor_user_id" name="idor_user_id" placeholder="2">
            <input type="submit" value="Zobacz profil">
        </form>

        <?php if ($idor_user_data): ?>
            <h4 style="margin-top:20px;">Prywatny profil użytkownika: <?php echo htmlspecialchars($idor_user_data['username']); ?></h4>
            <ul>
                <li><strong>ID:</strong> <?php echo htmlspecialchars($idor_user_data['id']); ?></li>
                <li><strong>Rola:</strong> <?php echo htmlspecialchars($idor_user_data['role']); ?></li>
                <li><strong>Super Tajna Notatka:</strong> <span style="color: #ff4a4a;"><?php echo htmlspecialchars($idor_user_data['secret_note']); ?></span></li>
            </ul>
        <?php elseif (isset($_GET['idor_user_id'])): ?>
            <p style="margin-top:20px;">Użytkownik o podanym ID nie istnieje.</p>
        <?php endif; ?>
    </div>

</div> <!-- Koniec .container -->

</body>
</html>