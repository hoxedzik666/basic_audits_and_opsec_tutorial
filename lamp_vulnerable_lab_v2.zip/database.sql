CREATE DATABASE IF NOT EXISTS lab_db;
USE lab_db;

DROP TABLE IF EXISTS users;
CREATE TABLE users (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    role VARCHAR(50) NOT NULL,
    secret_note VARCHAR(100) NOT NULL
);

INSERT INTO users (username, role, secret_note) VALUES 
('admin', 'Administrator', 'FLAG{Sztywne_Haslo_Szefa_1337}'),
('monter77', 'Serwisant', 'Moje tajne notatki: sprawdzic bezpieczenstwo bazy danych'),
('charli3', 'Moderator', 'Zapomnialem zmienic domyslnego hasla...');